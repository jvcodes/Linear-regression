# Regression using Python

All projects are implementation of some regression techniques using many different datasets.

Every project has its one README which will provide more information for project itself.

### Note

Folder **algorithms_numpy** has algorithms wrote from scratch using only numpy. Some projects are implementing those algorithms as well and you are free to use them or improve them.

### License

Each project has MIT license.
